package com.example.audiosignal;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
    // originally from http://marblemice.blogspot.com/2010/04/generate-and-play-tone-in-android.html
    // and modified by Steve Pomeroy <steve@staticfree.info>
	private int bitrate=2;
    private  int duration = 16; // seconds
    private  int sampleRate = 8000;
    private int numSamples = duration * sampleRate;
    private double sample[] = new double[numSamples];
    private double freqOfTone1 = 2000; // hz
    private double freqOfTone0 = 1200; 
    private double signalbits[]=new double[16];
    private  byte generatedSnd[] = new byte[2 * numSamples];
     AudioTrack audioTrack ;

    Handler handler = new Handler();
	private EditText bitratetext;
	private EditText signaltext;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        bitratetext= (EditText)this.findViewById(R.id.editText1);
        signaltext= (EditText)this.findViewById(R.id.editText2);
        Button playbtn=(Button)this.findViewById(R.id.playbtn);
         audioTrack = new AudioTrack(AudioManager.STREAM_SYSTEM,
                sampleRate, AudioFormat.CHANNEL_CONFIGURATION_MONO,
                AudioFormat.ENCODING_PCM_16BIT, generatedSnd.length,
                AudioTrack.MODE_STREAM);
        
        playbtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				 // Use a new tread as this can take a while
		        final Thread thread = new Thread(new Runnable() {
		            public void run() {
		            	
		                bitrate=Integer.valueOf(MainActivity.this.bitratetext.getText().toString());
		                int tempsignal=Integer.valueOf(MainActivity.this.signaltext.getText().toString());
		                for(int i=0;i<16;i++){
		                	signalbits[i]=tempsignal&0x01;
		                	tempsignal=tempsignal>>1;
		                   Log.i(""+i,"i "+signalbits[i]);
		                }

		            	
		                genTone();
		                handler.post(new Runnable() {

		                    public void run() {
		                        playSound();
		                    }
		                });
		            }
		        });
		        thread.start();
			}
		});
        
        bitrate=Integer.valueOf(bitratetext.getText().toString());
        
        
        
        
        
        
    }

    @Override
    protected void onResume() {
        super.onResume();

       
    }

    void genTone(){
        // fill out the array
    	
    	
    	
    	
        for (int i = 0; i < numSamples; ++i) {
        	
        	int j=i/(sampleRate/bitrate);
        	if(j<16){
	        	if (signalbits[j]==0x01){
	        		sample[i] = Math.sin(2 * Math.PI * i / (sampleRate/freqOfTone1));
	        	}
	        	else{
	        		sample[i] = Math.sin(2 * Math.PI * i / (sampleRate/freqOfTone0));
	
	        	}
        	}else{
        		sample[i]=0;
        	}
        	
        }

        // convert to 16 bit pcm sound array
        // assumes the sample buffer is normalised.
        int idx = 0;
        for (final double dVal : sample) {
            // scale to maximum amplitude
            final short val = (short) ((dVal * 32767));
            // in 16 bit wav PCM, first byte is the low order byte
            generatedSnd[idx++] = (byte) (val & 0x00ff);
            generatedSnd[idx++] = (byte) ((val & 0xff00) >>> 8);

        }
    }

    void playSound(){
    	audioTrack.stop();
    	audioTrack.release();
    	
         audioTrack = new AudioTrack(AudioManager.STREAM_SYSTEM,
                sampleRate, AudioFormat.CHANNEL_CONFIGURATION_MONO,
                AudioFormat.ENCODING_PCM_16BIT, generatedSnd.length,
                AudioTrack.MODE_STREAM);
        audioTrack.setStereoVolume(0.0f, 1.0f);
        audioTrack.write(generatedSnd, 0, generatedSnd.length);
        audioTrack.play();
    }
}
